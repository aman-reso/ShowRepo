package `in`.conscent.mylibrary

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DisplayCategoryList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_display_category_list)
    }
}